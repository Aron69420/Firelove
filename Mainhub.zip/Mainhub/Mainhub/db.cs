﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SQLite;
using System;
using System.Collections.Generic;
using System.Data.SQLite;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using static Mainhub.db;

namespace Mainhub
{
    public class User
    {
        public int UserID { get; set; }
        public string name { get; set; }
        public int Alter { get; set; }
        public int GenderID { get; set; }
    }

    public class db
    {
        private static string connectionString = @"Data Source=C:\Users\leons\OneDrive\Schule\Software\Mainhub\DB\FireLove20.db";
        private static SQLiteConnection connection = new SQLiteConnection(connectionString);

        public static List<User> LoadUsers()
        {
            List<User> userlist = new List<User>();
            // Dateipfad zur Datenbank

            connection.Open();
            // Tabelle User auswählen
            var cmd = connection.CreateCommand();
            cmd.CommandText = "SELECT * FROM User";
            cmd.CommandType = System.Data.CommandType.Text;
            var reader = cmd.ExecuteReader();

            while (reader.Read())
            {
                User user = new User
                {
                    UserID = reader.GetInt32(reader.GetOrdinal("UserID")),
                    name = reader.GetString(reader.GetOrdinal("Name")),
                    Alter = reader.GetInt32(reader.GetOrdinal("Alter")),
                    GenderID = reader.GetInt32(reader.GetOrdinal("GenderID")),
                };

                //Debug.WriteLine($"UserID: {user.UserID}, Name: {user.name}, Alter: {user.Alter}, GenderID: {user.GenderID}");
                userlist.Add(user);
            }

            connection.Close();
            return userlist;
        }

        public static List<string> LoadTable(string tablename)
        {
            try
            {
                connection.Open();
                SQLiteCommand cmd = connection.CreateCommand();
                cmd.CommandType = CommandType.Text;

                List<string> table = new();
                List<string> columnnames = new();
                cmd.CommandText = $"PRAGMA table_info({tablename})";
                SQLiteDataReader infoReader = cmd.ExecuteReader();
                while (infoReader.Read())
                {
                    columnnames.Add(infoReader["name"].ToString());
                }
                infoReader.Close();
                cmd.CommandText = $"SELECT * FROM {tablename}";
                SQLiteDataReader reader = cmd.ExecuteReader();

                //
                while (reader.Read())
                {
                    List<string> data = new();
                    foreach (string columnname in columnnames)
                    {
                        data.Add(reader[columnname].ToString());
                    }

                    string dataString = string.Join("/", data);
                    //Debug.WriteLine(dataString);
                    table.Add(dataString);
                }

                reader.Close();

                connection.Close();
                return table;
            }
            catch (Exception)
            {
                connection.Close();
                throw;
            }
        }
    }
}
