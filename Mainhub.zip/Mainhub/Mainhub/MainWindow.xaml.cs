﻿using System;
using System.Collections.Generic;
using System.Data.SQLite;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using static Mainhub.db;

namespace Mainhub
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            List<User> userlist = db.LoadUsers();
            cardname.Content = userlist[0].name;
        }


    private void test1_TextChanged(object sender, TextChangedEventArgs e)
    {

    }
}
}
